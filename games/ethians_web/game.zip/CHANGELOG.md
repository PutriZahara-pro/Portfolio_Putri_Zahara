# CHANGELOG - The Ethians Redeemed

## Version 1.0.1 (11 Mai 2025)

### Corrections de bugs
- Correction de la syntaxe Ren'Py : remplacement de `show screen battle_screen()` par `show screen battle_screen` dans `player_actions.rpy` (erreur de script bloquante).

## Version 1.0.0 (9 Mai 2025)

### Interface et Menu Principal
- **Ajout d'une vidéo en arrière-plan du menu principal** : Remplacement de l'image statique par une vidéo au format WebM pour une expérience plus dynamique
- **Intégration d'un dégradé par-dessus la vidéo** : Ajout de "top_gradiant.png" pour améliorer la lisibilité des éléments du menu
- **Optimisation de la qualité vidéo** : Configuration de l'accélération matérielle et des paramètres de taille pour éviter les problèmes de pixellisation
- **Repositionnement du bloc de menu** : Ajustement de la position verticale des boutons du menu principal et du sélecteur pour une meilleure présentation visuelle

### Sélecteur de Menu
- **Ajustement des décalages du sélecteur** : Configuration précise des positions pour chaque option du menu :
  - "Charger" : décalage de 10 pixels
  - "Préférences" : décalage de 20 pixels
  - "À propos" : décalage de 35 pixels
  - "Aide" : décalage de 42 pixels
  - "Quitter" : décalage de 53 pixels
- **Amélioration de l'animation** : Transition fluide du sélecteur entre les différentes options du menu

### Optimisations Techniques
- **Configuration vidéo améliorée** : Activation de l'accélération matérielle pour les vidéos
- **Désactivation du cache des surfaces** : Prévention des artefacts visuels lors de la lecture vidéo
- **Ajustement des paramètres d'affichage** : Configuration optimale pour la résolution 1920x1080

### Notes de Développement
- Le projet utilise Ren'Py 8.3.7
- Interface principale redessinée avec une police personnalisée "El Milagro de Empel.otf"
- Palette de couleurs dominante : rouge (#F21B38) et blanc pour une meilleure lisibilité

---

## Prochaines Étapes Envisagées
- Amélioration des transitions entre les écrans
- Optimisation des performances sur différentes configurations matérielles
- Ajout de nouvelles fonctionnalités d'interface utilisateur
- Extension des options de personnalisation


1. Analyse et refonte de la structure du projet
Analyse de la structure du projet battle-engine (référence GitHub).
Proposition d’une organisation claire :
scripts/battle/ pour la logique de combat (battle.rpy, player_actions.rpy, etc.)
scripts/define/ pour les définitions de personnages, monstres, compétences, objets.
2. Création d’un système de combat adapté à tes besoins
Tour par tour : 3 personnages jouables (gentils), 3 ennemis maximum (méchants), nombre variable selon la scène.
Suppression de la magie/mana : aucune gestion de MP, toutes les compétences/actions sont utilisables sans coût de mana.
Gestion du tour des joueurs :
Sélection du personnage actif.
Choix de l’action (attaque, défense, compétence, objet).
Sélection des cibles selon le type d’action.
Application des effets (dégâts, soin, buff, etc.).
Gestion du tour des ennemis : attaque automatique sur les personnages vivants.
3. Refactoring et création de fichiers clés
Création de player_actions.rpy
Contient : turn_actions, player_action, player_skill, target_select, écrans de sélection, et toute la logique d’application des effets.
Ajout des fonctions Python pour : gestion des tours, calcul des dégâts, ciblage, etc.
Refonte de battle.rpy
Ajout de la classe Skill (sans mana).
Initialisation des variables de combat.
Boucle principale adaptée pour intégrer le nouveau système (appels à turn_actions et gestion de la victoire/défaite).
Positionnement automatique des sprites ennemis.
Ajout de la gestion dynamique du nombre d’ennemis (1 à 3).
4. Adaptation graphique et transformations
Création/ajout de transformations dans transforms.rpy :
Nouvelle transformation battle_scale pour afficher correctement les sprites 4000x4000 en combat (zoom 0.13).
Animations de combat : char_sway, attack_move, enemy_hit, player_hit, dodge_move, attack_dash, shake_fade.
Conseils sur l’utilisation de ces transformations dans les écrans de combat pour garantir un affichage cohérent et esthétique.
5. Conseils et bonnes pratiques
Conseils pour la création de compétences (Skill) et leur assignation aux personnages.
Conseils pour l’ajout de versions spécifiques des sprites pour le combat (suffixe _fight).
Explications sur l’adaptation des écrans et sur la possibilité d’ajuster le zoom si besoin.
RÉSUMÉ DES FICHIERS MODIFIÉS/CRÉÉS
scripts/battle/player_actions.rpy : Nouveau — toute la logique d’action joueur.
scripts/battle/battle.rpy : Modifié — adaptation de la boucle principale, ajout de la classe Skill, variables et logique sans mana.
scripts/transforms.rpy : Modifié — ajout des transformations pour l’affichage et les animations des sprites 4000x4000.
FONCTIONNALITÉS MAJEURES AJOUTÉES
Système de combat tour par tour sans magie/mana.
Gestion dynamique du nombre d’ennemis (jusqu’à 3).
Adaptation graphique pour sprites HD.
Architecture de code inspirée des meilleurs moteurs open source Ren’Py RPG.