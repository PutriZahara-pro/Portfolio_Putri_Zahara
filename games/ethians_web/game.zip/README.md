# The Ethians Redeemed

## À propos du projet
"The Ethians Redeemed" est un visual novel développé avec Ren'Py 8.3.7. Le jeu présente une interface utilisateur moderne avec un menu principal dynamique intégrant une vidéo en arrière-plan et des animations fluides pour la navigation.

## Caractéristiques principales
- **Interface utilisateur immersive** avec vidéo en arrière-plan
- **Système de menu animé** avec sélecteur visuel
- **Design moderne** utilisant une palette de couleurs rouge et blanc
- **Polices personnalisées** pour une identité visuelle unique
- **Optimisations techniques** pour une expérience fluide

## Structure du projet
```
The ethians redeemed/
├── game/
│   ├── gui/                    # Ressources graphiques de l'interface
│   │   ├── backgound_menu.webm # Vidéo d'arrière-plan du menu
│   │   ├── top_gradiant.png    # Dégradé superposé à la vidéo
│   │   ├── menu_selector.png   # Indicateur de sélection du menu
│   │   └── ...                 # Autres éléments d'interface
│   ├── fonts/                  # Polices personnalisées
│   │   └── El Milagro de Empel.otf
│   ├── screens.rpy             # Définition des écrans et de l'interface
│   ├── gui.rpy                 # Configuration de l'interface graphique
│   ├── script.rpy              # Script principal du jeu
│   ├── video_background.rpy    # Configuration de l'arrière-plan vidéo
│   └── video_config.rpy        # Optimisations pour la lecture vidéo
├── CHANGELOG.md                # Journal des modifications
└── README.md                   # Ce fichier
```

## Modifications récentes
Consultez le [CHANGELOG](CHANGELOG.md) pour un historique détaillé des modifications apportées au projet.

## Développement
Le projet est développé avec Ren'Py 8.3.7. Les principales améliorations ont porté sur :
- L'intégration d'une vidéo en arrière-plan du menu principal
- L'optimisation de la qualité d'affichage
- Le repositionnement et l'animation des éléments du menu
- L'ajustement précis du sélecteur de menu pour chaque option

## Comment lancer le jeu
1. Assurez-vous d'avoir Ren'Py 8.3.7 ou supérieur installé
2. Ouvrez le lanceur Ren'Py
3. Ajoutez le dossier "The ethians redeemed" comme projet
4. Cliquez sur "Lancer le projet"

## Crédits
- Développé avec Ren'Py (https://www.renpy.org/)
- Police "El Milagro de Empel" utilisée pour l'interface
